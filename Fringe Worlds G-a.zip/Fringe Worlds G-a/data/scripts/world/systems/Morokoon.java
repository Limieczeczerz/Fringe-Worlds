package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.util.Misc;

public class Morokoon {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Morokoon");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		PlanetAPI star = system.initStar("morokoon",
				"star_yellow", 
				1000f,
				500, // extent of corona outside star
				10f, // solar wind burn level
				1f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5

		PlanetAPI gyas_a = system.addPlanet("gyas_a", star, "Phagocyte", "fire_giant", 0, 330, 2300, 80);
		gyas_a.getSpec().setPlanetColor( new Color(75, 0, 65,255) );
		gyas_a.applySpecChanges();
		gyas_a.setCustomDescriptionId("planet_gyas_a");
		system.addCorona(gyas_a, Terrain.CORONA_AKA_MAINYU,
				300f, // radius outside planet
				5f, // burn level of "wind"
				0f, // flare probability
				1f // CR loss mult while in it
		);

		SectorEntityToken empty_a = system.addCustomEntity("empty_a", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"stable_location", // type of object, defined in custom_entities.json
				"neutral"); // faction
		empty_a.setCircularOrbitPointingDown(system.getEntityById("morokoon"), 245, 3000, 200);

		PlanetAPI ignacy = system.addPlanet("ignacy", star, "Ignacy", "rocky_unstable", 60, 140, 3500, 150);

		PlanetAPI nighttime = system.addPlanet("nighttime", star, "Night Time", "toxic", 180, 110, 7100, 300);

		JumpPointAPI inner_jump = Global.getFactory().createJumpPoint("inner_jump", "Night Night Jump-point");
		inner_jump.setCircularOrbit(system.getEntityById("morokoon"), 0, 6500, 200);
		inner_jump.setRelatedPlanet(nighttime);
		inner_jump.setStandardWormholeToHyperspaceVisual();
		system.addEntity(inner_jump);

		SectorEntityToken gate = system.addCustomEntity("morokoon_gate", // unique id
				"Morokoon Gate", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction
		gate.setCircularOrbit(system.getEntityById("morokoon"), 0, 7500, 600);

		PlanetAPI yendore = system.addPlanet("yendore", star, "Yendore", "desert", 0, 120, 9000, 400);
		yendore.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		yendore.getSpec().setGlowColor( new Color(255,175,171,255) );
		yendore.getSpec().setUseReverseLightForGlow(true);
		yendore.applySpecChanges();
		yendore.setCustomDescriptionId("planet_yendore");
		yendore.setInteractionImage("illustrations", "mine");

		system.addRingBand(yendore, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 400, 30f, Terrain.RING, "Aspa");

		JumpPointAPI outer_jump = Global.getFactory().createJumpPoint("inner_jump", "Parpatout Jump-point");
		outer_jump.setCircularOrbit(system.getEntityById("morokoon"), 0, 10000, 500);
		outer_jump.setRelatedPlanet(yendore);
		outer_jump.setStandardWormholeToHyperspaceVisual();
		system.addEntity(outer_jump);
		SectorEntityToken parpatout = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						6f, // min asteroid radius
						20f, // max asteroid radius
						"Nona Lagrange Le Parpatout")); // null for default name
		parpatout.setCircularOrbit(star, 0, 10000, 500);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 14500, 1000, Terrain.RING, null);
		PlanetAPI frozone_a = system.addPlanet("frozone_a", star, "Dermit", "frozen2", 600, 110, 15000, 1200);
		frozone_a.setCustomDescriptionId("planet_frozone");
		
		PlanetAPI frozone_b = system.addPlanet("frozone_b", star, "Mazomit", "frozen3", 800, 150, 16000, 1300);

		SectorEntityToken empty_b = system.addCustomEntity("empty_b", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"stable_location", // type of object, defined in custom_entities.json
				"neutral"); // faction
		empty_b.setCircularOrbitPointingDown(system.getEntityById("morokoon"), 240, 14000, 750);

		PlanetAPI loner = system.addPlanet("loner", star, "Arbakan", "cryovolcanic", 0, 170, 22000, 1500);
		Misc.initConditionMarket(loner);
		loner.getMarket().addCondition(Conditions.DECIVILIZED);
		loner.getMarket().addCondition(Conditions.POLLUTION);
		loner.getMarket().addCondition(Conditions.RUINS_WIDESPREAD);
		loner.getMarket().getFirstCondition(Conditions.RUINS_WIDESPREAD).setSurveyed(true);

		loner.getMarket().addCondition(Conditions.VOLATILES_ABUNDANT);
		loner.getMarket().addCondition(Conditions.ORGANICS_COMMON);
		loner.getMarket().addCondition(Conditions.POOR_LIGHT);
		loner.getMarket().addCondition(Conditions.TECTONIC_ACTIVITY);
		loner.getMarket().addCondition(Conditions.VERY_COLD);
		loner.setCustomDescriptionId("planet_loner");

		PlanetAPI loner_a = system.addPlanet("loner_a", loner, "Mni-Faon", "barren2", 800, 60, 440, 60);
		system.addRingBand(loner, "misc", "rings_ice0", 256f, 3, Color.white, 256f, 800, 100f, Terrain.RING, null);

		SectorEntityToken spy = system.addCustomEntity("spy", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"sensor_array", // type of object, defined in custom_entities.json
				"persean"); // faction
		spy.setCircularOrbitPointingDown(system.getEntityById("morokoon"), 240, 18500, 1500);
		
		system.autogenerateHyperspaceJumpPoints(true, true);
	}

	
}









