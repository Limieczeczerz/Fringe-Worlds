package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.campaign.LocationAPI;

import data.scripts.world.systems.Parkapec;
import data.scripts.world.systems.Cappuccino;
import data.scripts.world.systems.Morokoon;
import data.scripts.world.systems.Syzygy;
import data.scripts.world.systems.Vancouver;
import data.scripts.world.systems.Moronia;
import data.scripts.world.systems.Abin_Cresc;
import data.scripts.world.systems.No_Bono;

//import data.scripts.systems.Deathcon;
public class ModPlugin extends BaseModPlugin {

    public void onNewGame()
    {
            new Parkapec().generate(Global.getSector());
            new Cappuccino().generate(Global.getSector());
            new Morokoon().generate(Global.getSector());
            new Syzygy().generate(Global.getSector());
            new Vancouver().generate(Global.getSector());
            new Moronia().generate(Global.getSector());
            new Abin_Cresc().generate(Global.getSector());
            new No_Bono().generate(Global.getSector());

            LocationAPI hyper = Global.getSector().getHyperspace();
            SectorEntityToken self_exiled_label = hyper.addCustomEntity("self_exiled_label_id", null, "self_exiled_label", null);
            self_exiled_label.setFixedLocation(-21000, -9100);
    }
}