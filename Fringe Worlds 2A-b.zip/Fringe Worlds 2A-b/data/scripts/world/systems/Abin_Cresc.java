package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

public class Abin_Cresc {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Abin Cresc");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");

		PlanetAPI star = system.initStar("abin_cresc", // unique id for this star
				"star_red_dwarf", // id in planets.json
				800f,		// radius (in pixels at default zoom)
				600, // corona radius, from star edge
				5f, // solar wind burn level
				0.5f, // flare probability
				2f); // cr loss mult
		system.setLightColor(new Color(250, 63, 0)); // light color in entire system, affects all entities

		PlanetAPI gangregis_khan = system.addPlanet("gangregis_khan", star, "Gangregis Khan", "fire_giant", 50, 340, 1600, 50);
		gangregis_khan.setCustomDescriptionId("planet_gangregis_khan");
		system.addCorona(gangregis_khan, Terrain.CORONA_AKA_MAINYU,
				300f, // radius outside planet
				5f, // burn level of "wind"
				0f, // flare probability
				1f // CR loss mult while in it
		);

		//system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 3850, 80f);
		//system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 4000, 80f);
		//system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4120, 130f);
		//system.addAsteroidBelt(star, 100, 4000, 100, 256, 140, Terrain.ASTEROID_BELT, "Am Alone");

		PlanetAPI denyza = system.addPlanet("denyza", star, "Denyza", "arid", 50, 140, 6600, 540);
		denyza.setCustomDescriptionId("planet_denyza");
		denyza.getSpec().setPitch(20f);
		denyza.getSpec().setTilt(88f);
		denyza.applySpecChanges();

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Ogon Jump-point");
		jumpPoint.setCircularOrbit( star, 360, 5000, 300);
		jumpPoint.setRelatedPlanet(denyza);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint);

		SectorEntityToken don_eladio = system.addCustomEntity("don_eladio", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"stable_location", // type of object, defined in custom_entities.json
				"neutral"); // faction
		don_eladio.setCircularOrbitPointingDown(star, 60, 9200, 200);

		PlanetAPI maronia = system.addPlanet("maronia", star, "Maronia", "barren_venuslike", 200, 80, 4400, 420);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				4, 5, // min/max entities to add
				10000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds
		
		
		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}
