package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

public class Morokoon {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Morokoon");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");

		SectorEntityToken hybrasil_nebula = Misc.addNebulaFromPNG("data/campaign/terrain/hybrasil_nebula.png",
				0, 0, // center of nebula
				system, // location to add to
				"terrain", "nebula_blue", // "nebula_blue", // texture to use, uses xxx_map for map
				4, 4, StarAge.YOUNG); // number of cells in texture

		PlanetAPI star = system.initStar("morokoon", "star_red_dwarf", 500, 500);
		system.initNonStarCenter();

		PlanetAPI moron = system.addPlanet("marra", star, "Marra", "desert", 0, 140, 4000, 250);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Marra Jump-point");
		jumpPoint.setCircularOrbit(system.getEntityById("morokoon"), 60, 5000, 240);
		system.addEntity(jumpPoint);

		jumpPoint.setRelatedPlanet(moron);

		SectorEntityToken empty_a = system.addCustomEntity("empty_a", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"stable_location", // type of object, defined in custom_entities.json
				"neutral"); // faction
		empty_a.setCircularOrbitPointingDown( system.getEntityById("morokoon"), -60, 11000, 500);

		PlanetAPI crabert = system.addPlanet("crabert", star, "Crabert", "frozen1", 0, 90, 15000, 700);

		PlanetAPI pineapple = system.addPlanet("pineapple", star, "Pineapple", "rocky_ice", 400, 100, 18000, 800);

		SectorEntityToken empty_b = system.addCustomEntity("empty_b", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"stable_location", // type of object, defined in custom_entities.json
				"neutral"); // faction
		empty_b.setCircularOrbitPointingDown(system.getEntityById("morokoon"), -60, 20000, 2000);
		
		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				1, 2, // min/max entities to add
				21000, // radius to start adding at
				1, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				true); // whether to allow habitable worlds

		system.autogenerateHyperspaceJumpPoints(true, true);
	}


}
