package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.util.Misc;

import data.scripts.world.systems.Parkapec;
import data.scripts.world.systems.Cappuccino;

//import data.scripts.systems.Deathcon;
//import data.scripts.systems.Morokoon; unused for now
public class ModPlugin extends BaseModPlugin {

    public void onNewGame()
    {
            new Parkapec().generate(Global.getSector());
            new Cappuccino().generate(Global.getSector());
            //new Deathcon().generate(Global.getSector());

           //new Morokoon().generate(Global.getSector());

    }
}