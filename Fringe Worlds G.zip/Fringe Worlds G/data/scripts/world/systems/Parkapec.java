package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

public class Parkapec {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Parkapec");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");

		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("parkapec", // unique id for this star
				"star_blue_giant",  // id in planets.json
				1600f,          // radius (in pixels at default zoom)
				1000, // corona radius, from star edge
				5f, // solar wind burn level
				0.5f, // flare probability
				2f); // cr loss mult

		system.setLightColor(new Color(225, 226, 242)); // light color in entire system, affects all entities

		SectorEntityToken lamar_buoy = system.addCustomEntity("lamar_buoy", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"luddic_church"); // faction

		lamar_buoy.setCircularOrbitPointingDown(star, 0, 4000, 100);

		PlanetAPI new_bebop = system.addPlanet("new_bebop", star, "New Bebop", "water_giant", 180, 250, 13000, 600);

		PlanetAPI niber = system.addPlanet("niber", star, "Niber", "gas_giant", 0, 310, 12000, 680);
		//niber.setCustomDescriptionId("planet_niber");

		PlanetAPI marko = system.addPlanet("marko", niber, "Marko", "water", 45, 100, 800, 50);
		marko.setCustomDescriptionId("planet_marko");
		marko.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		marko.getSpec().setGlowColor(new Color(255,241,227,255));
		marko.getSpec().setUseReverseLightForGlow(true);
		marko.applySpecChanges();

	//	SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
	//			new MagneticFieldParams(150f, // terrain effect band width
	//					250, // terrain effect middle radius
	//					marko, // entity that it's around
	//					100f, // visual band start
	//					400f, // visual band end
	//					new Color(189, 79, 57, 50), // base color
	//					1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
	//					new Color(125, 52, 37, 130),
	//					new Color(196, 82, 59, 150),
	//					new Color(255, 106, 77, 190),
	//					new Color(255, 140, 117, 240),
	//					new Color(184, 84, 72, 255),
	//					new Color(186, 50, 24),
	//					new Color(156, 43, 20)
	//			));
	//	field.setCircularOrbit(marko, 0, 0, 30);

		PlanetAPI kathryn = system.addPlanet("kathryn", star, "Kathryn", "frozen1", 1000, 95, 18000, 1500);
		kathryn.setCustomDescriptionId("planet_kathryn");
		//kathryn.getMarket().addCondition(Conditions.ORE_SPARSE);
		//kathryn.getMarket().addCondition(Conditions.VOLATILES_DIFFUSE);
		//kathryn.getMarket().addCondition(Conditions.VERY_COLD);

		SectorEntityToken oro = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						600f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						10f, // max asteroid radius
						"Aramarra")); // null for default name

		SectorEntityToken ara = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						600f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						10f, // max asteroid radius
						"Oromorro")); // null for default name

		ara.setCircularOrbit(star, 50, 7500, 400);
		oro.setCircularOrbit(star, 250, 8500, 550);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("ara_jump", "Ara-Oro Jump-point");
		jumpPoint.setCircularOrbit(star, 50, 7500, 400);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 14200, 3200f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 14400, 4000f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 14600, 5200f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 14800, 3200f);

		SectorEntityToken ring = system.addTerrain(Terrain.RING, new RingParams(600 + 256, 15500, null, "Kolbocyt"));
		ring.setCircularOrbit(star, 0, 0, 100);


		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 15000, 3200f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 15100, 4800f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 15200, 6400f);

		ring = system.addTerrain(Terrain.RING, new RingParams(200 + 256, 15100, null, "Kolbocyt"));
		ring.setCircularOrbit(star, 0, 0, 100);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 15300, 5600f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 15400, 7200f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 15500, 8800f);

		// add one ring that covers all of the above
		ring = system.addTerrain(Terrain.RING, new RingParams(200 + 256, 15400, null, "Kolbocyt"));
		ring.setCircularOrbit(star, 0, 0, 100);


		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 15500, 4000f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 15600, 5600f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 15700, 6400f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 15800, 7200f);

		// add one ring that covers all of the above
		ring = system.addTerrain(Terrain.RING, new RingParams(300 + 256, 15650, null, "Kolbocyt"));
		ring.setCircularOrbit(star, 0, 0, 100);

		PlanetAPI lamar = system.addPlanet("lamar", star, "Lamar", "toxic_cold", 1500, 120, 19000, 1600);
		lamar.setCustomDescriptionId("planet_lamar");

		SectorEntityToken lamar_relay = system.addCustomEntity("lamar_relay", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"luddic_church"); // faction

		lamar_relay.setCircularOrbitPointingDown(star, 0, 12500, 200);

		SectorEntityToken pirateStation = system.addCustomEntity("grozel", "Grozel Station", "station_midline2", "luddic_church");
		pirateStation.setCustomDescriptionId("station_grozel");
		pirateStation.setInteractionImage("illustrations", "urban00");
		pirateStation.setCircularOrbitPointingDown(star, 200, 16100, 1000);

		

		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}










