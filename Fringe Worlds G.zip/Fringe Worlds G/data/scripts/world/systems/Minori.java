package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.util.Misc;

public class Minori {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Minori");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background6.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("minori", // unique id for star
				"star_red_dwarf", // id in planets.json
				575f,		// radius (in pixels at default zoom)
				400, // extent of corona outside star
				5f, // solar wind burn level
				1f, // flare probability
				2f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(210, 230, 255)); // light color in entire system, affects all entities
		
		
		PlanetAPI kumarikandam_b = system.addPlanet("kumari_aru", kumarikandam_star, "Kumari Aru", "gas_giant", 270, 300, 2800, 80);
		kumarikandam_b.getSpec().setPlanetColor(new Color(150,235,245,255));
		kumarikandam_b.getSpec().setAtmosphereColor(new Color(150,170,240,150));
		kumarikandam_b.getSpec().setCloudColor(new Color(180,250,240,200));
		kumarikandam_b.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		kumarikandam_b.getSpec().setGlowColor(new Color(250,50,105,100));
		kumarikandam_b.getSpec().setUseReverseLightForGlow(true);
		kumarikandam_b.getSpec().setIconColor(new Color(180,255,225,255));
		kumarikandam_b.applySpecChanges();
		kumarikandam_b.setCustomDescriptionId("planet_kumari_aru");
		
		
			// Beholder Station
			SectorEntityToken beholder_station = system.addCustomEntity("beholder_station", "Beholder Station", "station_side05", "luddic_church");
			beholder_station.setCircularOrbitPointingDown(system.getEntityById("kumari_aru"), 270, 430, 30);		
			beholder_station.setCustomDescriptionId("station_beholder");
			beholder_station.setInteractionImage("illustrations", "luddic_shrine");
			
			// And the moons of Kumari Aru
			// Makal : sulphurous outgassing like Io
			PlanetAPI kumarikandam_b1 = system.addPlanet("makal", kumarikandam_b, "Makal", "barren", 270, 60, 520, 40);
			kumarikandam_b1.getSpec().setTexture(Global.getSettings().getSpriteName("planets", "barren02"));

			kumarikandam_b1.getSpec().setPlanetColor(new Color(255,235,150,255));
			// kumarikandam_b1.getSpec().setAtmosphereColor(new Color(255,245,100,150));
			// kumarikandam_b1.getSpec().setCloudColor(new Color(255,215,50,50));
			//kumarikandam_b1.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
			kumarikandam_b1.applySpecChanges();
			
			PlanetAPI kumarikandam_b2 = system.addPlanet("kulantai", kumarikandam_b, "Kulantai", "barren-bombarded", 270, 40, 650, 35);
			//PlanetAPI kumarikandam_b3 = system.addPlanet("nanpan", kumarikandam_b, "Nanpan", "barren", 270, 40, 600, 90);
			
			// Kumari Aru trojans - L4 leads, L5 follows
			SectorEntityToken kumari_aruL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						300f, // min radius
						500f, // max radius
						16, // min asteroid count
						24, // max asteroid count
						4f, // min asteroid radius 
						16f, // max asteroid radius
						"Kumari Aru L4 Asteroids")); // null for default name
			
			SectorEntityToken kumari_aruL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						300f, // min radius
						500f, // max radius
						16, // min asteroid count
						24, // max asteroid count
						4f, // min asteroid radius 
						16f, // max asteroid radius
						"Kumari Aru L5 Asteroids")); // null for default name
			
			kumari_aruL4.setCircularOrbit(kumarikandam_star, 270 +60, 2800, 80);
			kumari_aruL5.setCircularOrbit(kumarikandam_star, 270 -60, 2800, 80);
			
			SectorEntityToken kumari_aru_l5_loc = system.addCustomEntity(null, null, "comm_relay_makeshift", Factions.LUDDIC_PATH); 
			kumari_aru_l5_loc.setCircularOrbitPointingDown(kumarikandam_star, 270 -60, 2800, 80);
			
			
		PlanetAPI chalcedon = system.addPlanet("chalcedon", kumarikandam_star, "Chalcedon", "terran-eccentric", 220, 160, 4300, 180);
		chalcedon.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		chalcedon.getSpec().setGlowColor(new Color(170,255,240,255));
		chalcedon.getSpec().setUseReverseLightForGlow(true);
		chalcedon.applySpecChanges();
		chalcedon.setCustomDescriptionId("planet_chalcedon");
		chalcedon.setInteractionImage("illustrations", "chalcedon");
		
		system.autogenerateHyperspaceJumpPoints(true, true);
		
		//Misc.setFullySurveyed(kumarikandam_b.getMarket(), null, false);
	}
}
